import random as rand
import math
import time
ruchy = 0 #50=>wygrana
zdrowie = 10 #0=>przegrana
ryzyko = 0 #mniejszy numer => ryzyko++
los = 0 #zdarzenie
szybkosc = 1
obrazenia = 4

def wrog(mnoznik): #pojawienie sie wroga
    global zdrowie
    global obrazenia 
    print("nadciaga wrog!\n")
    time.sleep(1)
    wrog_zdr=mnoznik*ruchy/2+1 #zdrowie wroga    
    wrog_obr=mnoznik/5*ruchy/5+1 #obrazenia wroga
    while wrog_zdr > 0 and zdrowie > 0:
         print("atakujesz...") 
         time.sleep(1)
         print(str(obrazenia)+"!!!")
         wrog_zdr -= obrazenia #^atak
         time.sleep(1.5)
         if wrog_zdr == 0:
             continue
         print("wrog atakuje!")
         time.sleep(1)
         print(str(wrog_obr)+"!!!")
         zdrowie -= wrog_obr #^atak wroga
         time.sleep(1.5)
    time.sleep(1)

def jeden_dwa(): #1-2
    global zdrowie
    print("moze faktycznie wygrasz...")
    zdrowie += 10
    time.sleep(1)

def trzy_cztery(): #3-4
    wrog(20)
    time.sleep(1)

def piec(): #5
    global ruchy   
    if ruchy>5:
        print("umrzesz tutaj ... :)")
        ruchy -= 5
    elif ruchy<5:
        print("ujdzie...")
    time.sleep(1)

def szesc_siedem(): #6-7
    global obrazenia
    print("czujesz moc jak przeszywa twoje cialo")
    obrazenia += 1
    time.sleep(1)

def osiem_dziesiec(): #8-10
    global zdrowie
    print("czujesz orzezwienie")
    zdrowie+=5
    time.sleep(1)

def jedenascie_czternascie(): #11-14
    wrog(1.5)
    time.sleep(1)

def pietnascie_szesnascie(): #15-16
    global szybkosc
    if szybkosc != 1:
        print("czujesz sie ciezej")
        szybkosc-=1
    elif szybkosc == 1:
        print("nic sie nie wydarzylo..")
    time.sleep(1)

def siedemnascie_dwadziescia(): #17-20
    global szybkosc
    global ruchy
    print("SZYBCIEJ!!!")
    szybkosc += 1
    ruchy += 1
    time.sleep(1)

def dwadziescia_jeden(): #21-25
    wrog(1)
    time.sleep(1)

def dwadziescia_szesc(): #26-28
    global zdrowie
    print("ups >.<")
    zdrowie -= 3
    time.sleep(1)

def dwadziescia_dziewiec(): #29-30
    global zdrowie
    print("wez gleboki wdech...")
    zdrowie += 1

def eventy(): 
    global los
    if los==1 or los==2:
        jeden_dwa()
    elif los==3 or los==4:
        trzy_cztery()
    elif los==5:
        piec()
    elif los==6 or los==7:
        szesc_siedem()
    elif los>=8 and los<=10:
        osiem_dziesiec()
    elif los>=11 and los <=14:
        jedenascie_czternascie()
    elif los==15 or los==16:
        pietnascie_szesnascie()
    elif los>=17 and los<=20:
        siedemnascie_dwadziescia()
    elif los>=21 and los<=25:
        dwadziescia_jeden()
    elif los>=26 and los<=28:
        dwadziescia_szesc()
    elif los==29 or los==30:
        dwadziescia_dziewiec()

while ruchy <50 and zdrowie >0: 
    print("zdrowie: "+str(zdrowie))
    print("runda: "+str(ruchy))
    print("podaj skale ryzyka(1-4):")
    ryzyko=int(input())
    if ryzyko > 5:
        ryzyko=4
    elif ryzyko < 1:
        ryzyko=1
    ruchy += szybkosc
    if ryzyko==1:
         los=rand.randint(1,5)
    elif ryzyko==2:
        los = rand.randint(4,10)
    elif ryzyko == 3:
        los = rand.randint(8,17)
    elif ryzyko == 4:
        los = rand.randint(15,30)
    print(los)
    eventy()
if zdrowie<=0:
    print("przegrywasz!\n Dotrwales do rundy: "+str(ruchy))
elif ruchy>=30:
    print("gratuluje wygrales!")
